generated_file_path = '/home/taufiq/Documents/python/code/python3/xlsxwriter/GUI/generated_file/'
kadaluarsa = '12/27/2050 12:44:03'
        